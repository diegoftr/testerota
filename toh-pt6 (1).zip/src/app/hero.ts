export interface Hero {
  id: number;
  name: string;
}
